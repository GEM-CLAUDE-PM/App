import { useNotification } from './NotificationEngine';
import ModalForm, { FormRow, FormGrid, FormSection, FormFileUpload, inputCls, selectCls, BtnCancel, BtnSubmit } from './ModalForm';
import CameraCapture, { type CaptureResult } from './CameraCapture';
import VoiceCapture from './VoiceCapture';
import HSEImageAnalyzer, { type HSEAnalysisResult } from './HSEImageAnalyzer';
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { LayoutDashboard, Folder, TrendingUp, Clock, HardDrive, CheckCircle2, Lock, FileText, Image as ImageIcon, Files, ClipboardList, ExternalLink, BookOpen, UploadCloud, Loader2, Plus, Printer, Users, HardHat, Camera, ShieldAlert, Sun, MessageCircle, Network, HeartPulse, AlertTriangle, Mic, Edit3, Unlock, X, Award, Target, GraduationCap, Briefcase, ChevronRight, ArrowRight, Building2, CheckCircle, CircleDashed, ArrowLeft, ChevronDown, Cloud, Download, Eye, MoreVertical, ChevronLeft, Calendar, ShieldCheck, Trash2, Sparkles, User, Info, ChevronUp, Wrench, Truck, Fuel, Activity, Zap, Settings, AlertCircle, Search, Scan, FileSpreadsheet, Save, Calculator, Copy, Send } from 'lucide-react';
import { createDocument, submitDocument, getApprovalQueue, type ApprovalDoc } from './approvalEngine';
import { type UserContext, WORKFLOWS, type RoleId } from './permissions';
import ApprovalQueue from './ApprovalQueue';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
const COLORS = ['#3b82f6','#f59e0b','#10b981','#8b5cf6'];
import { OrgNode } from './dashboard/OrgChart';
import { genAI, GEM_MODEL, GEM_MODEL_QUALITY } from './gemini';

import type { DashboardProps } from './types';
import { db, useRealtimeSync } from './db';
import { HSEReportPrint } from './PrintService';

type HSEProps = DashboardProps;

/** Build ctx từ localStorage nếu không có prop — useMemo để stable reference, tránh infinite loop */
function useLocalCtx(ctxProp?: UserContext, projectIdProp?: string): { ctx: UserContext; projectId: string } {
  const roleId = (localStorage.getItem('gem_user_role') || 'chi_huy_truong') as RoleId;
  const userId = localStorage.getItem('gem_user_id') || `user_${roleId}`;
  const userName = localStorage.getItem('gem_user_name') || roleId;
  const projId = projectIdProp || localStorage.getItem('gem_last_project') || 'proj_default';
  // useMemo giữ stable object reference — không tạo object mới mỗi render
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const ctx = useMemo<UserContext>(
    () => ctxProp ?? { userId, userName, roleId },
    [ctxProp, userId, userName, roleId],
  );
  return { ctx, projectId: projId };
}

export default function HSEWorkspace({ project: selectedProject, projectId: projectIdProp, ctx: ctxProp }: HSEProps) {
  const { ctx, projectId } = useLocalCtx(ctxProp, projectIdProp);
  const { ok: notifOk, err: notifErr } = useNotification();
            // ── HSE WORKSPACE ĐẦYĐỦ ─────────────────────────────────────────
  // localStorage helpers removed — persistence via db.ts

  // ── Types ──────────────────────────────────────────────────────
  type IncidentLevel = 'near_miss'|'minor'|'medium'|'major'|'fatal';
  type TrainingStatus = 'scheduled'|'ongoing'|'completed'|'overdue';
  type ViolationLevel = 'nhe'|'trung'|'nghiem_trong';
  type InspectionResult = 'pass'|'fail'|'conditional';

  interface Incident {
    id:string; date:string; time:string; location:string;
    description:string; level:IncidentLevel;
    injured?:string; root_cause:string; action:string;
    status:'open'|'investigating'|'closed'; reporter:string;
  }
  interface Training {
    id:string; title:string; type:string;
    scheduled_date:string; duration_hours:number;
    trainer:string; participants:string[]; max_participants:number;
    status:TrainingStatus; pass_count:number; certificate_expiry_months:number;
    notes:string;
  }
  interface Violation {
    id:string; date:string; worker:string; contractor:string;
    description:string; level:ViolationLevel;
    photo_note:string; action:string; fine_amount:number;
    status:'open'|'resolved'; recurrence:boolean;
  }
  interface Inspection {
    id:string; date:string; inspector:string; area:string;
    checklist_items: {item:string; result:InspectionResult; note:string}[];
    overall:InspectionResult; follow_up:string; next_date:string;
  }

  // ── Seed data ──────────────────────────────────────────────────

  // ── Local state ────────────────────────────────────────────────
  // ── Approval wiring ──────────────────────────────────────────────────────
  const [hseApprovalQueue, setHseApprovalQueue] = useState<ApprovalDoc[]>([]);
  const [showApprovalPanel, setShowApprovalPanel] = useState(false);
  const [printHSE, setPrintHSE] = useState<{content:string}|null>(null);

  const refreshHseQueue = useCallback(() => {
    setHseApprovalQueue(getApprovalQueue(projectId, ctx));
  }, [projectId, ctx]);

  useEffect(() => { refreshHseQueue(); }, [refreshHseQueue]);

  type HseDocType = 'HSE_INCIDENT' | 'PERMIT_TO_WORK' | 'HSE_INSPECTION' | 'CAPA';

  const triggerHseDoc = useCallback((
    title: string,
    docType: HseDocType,
    data: Record<string, unknown> = {},
  ) => {
    if (!WORKFLOWS[docType]) return;
    const cr = createDocument({ projectId, docType, ctx, title, data });
    if (!cr.ok) { notifErr(`❌ ${(cr as any).error}`); return; }
    const sr = submitDocument(projectId, cr.data!.id, ctx);
    if (sr.ok) {
      refreshHseQueue();
      const el = document.createElement('div');
      el.className = 'fixed bottom-6 left-1/2 -translate-x-1/2 z-[9999] bg-orange-700 text-white text-sm font-bold px-5 py-3 rounded-2xl shadow-2xl';
      el.textContent = `✅ ${docType} "${title}" đã nộp duyệt`;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 3500);
    } else {
      notifErr(`❌ ${(sr as any).error}`);
    }
  }, [projectId, ctx, refreshHseQueue]);
  // ── /Approval wiring ──────────────────────────────────────────────────────

  const [hseTab, setHseTab]             = React.useState<'dashboard'|'incidents'|'trainings'|'violations'|'inspections'|'reports'|'ptw'>('dashboard');
  const [trainingView, setTrainingView] = React.useState<'classes'|'certs'>('classes');

  // ── PTW types ──────────────────────────────────────────────────────────────
  type PTWStatus = 'draft'|'pending'|'approved'|'active'|'closed'|'rejected';
  type PTWType = 'hot_work'|'confined_space'|'electrical'|'excavation'|'working_at_height'|'chemical'|'other';
  interface PTW {
    id: string; type: PTWType; title: string;
    requester: string; contractor: string; area: string;
    work_description: string; hazards: string; controls: string;
    start_date: string; end_date: string;
    status: PTWStatus; approved_by?: string; approved_at?: string;
    created_at: string;
  }
  interface ToolboxTalk {
    id: string; date: string; topic: string;
    conducted_by: string; area: string;
    attendees_count: number; key_points: string;
    created_at: string;
  }

  const PTW_TYPE_LABEL: Record<PTWType, string> = {
    hot_work: 'Công việc nóng (hàn/cắt)', confined_space: 'Không gian hạn chế',
    electrical: 'Điện — Cao thế', excavation: 'Đào đất / Hầm móng',
    working_at_height: 'Làm việc trên cao', chemical: 'Hóa chất nguy hiểm', other: 'Khác',
  };
  const PTW_STATUS_CFG: Record<PTWStatus, {label:string; cls:string}> = {
    draft:    { label:'Nháp',       cls:'bg-slate-100 text-slate-600' },
    pending:  { label:'Chờ duyệt',  cls:'bg-amber-100 text-amber-700' },
    approved: { label:'Đã duyệt',   cls:'bg-blue-100 text-blue-700' },
    active:   { label:'Đang thi công', cls:'bg-emerald-100 text-emerald-700' },
    closed:   { label:'Đã đóng',    cls:'bg-slate-100 text-slate-500' },
    rejected: { label:'Từ chối',    cls:'bg-rose-100 text-rose-700' },
  };

  // Safety checklist per PTW type — phải tick hết trước khi approve
  const PTW_CHECKLIST: Record<string, string[]> = {
    hot_work:           ["Đã kiểm tra nguồn cháy xung quanh","Có bình chữa cháy tại chỗ","Cách ly vật liệu dễ cháy","Người giám sát hỏa công có mặt","Đã thông báo ca trực PCCC"],
    working_at_height:  ["Đã lắp dây an toàn và điểm neo","Kiểm tra giàn giáo / thang leo","Lưới bảo vệ phía dưới","Không làm việc cao khi gió >10 m/s","Mũ bảo hộ + dây kéo dụng cụ"],
    confined_space:     ["Đo khí O2/CO/H2S trước khi vào","Có người giám sát bên ngoài","Dây thoát hiểm và mặt nạ dưỡng khí sẵn sàng","Thông gió cưỡng bức bật","Hệ thống liên lạc hoạt động"],
    electrical:         ["Cắt điện và khóa cầu dao (LOTO)","Kiểm tra không còn điện áp","Cách ly vùng làm việc","Kỹ thuật viên điện có chứng chỉ","Dụng cụ cách điện đúng cấp"],
    excavation:         ["Khảo sát ngầm công trình trước","Chống vách hố đào","Rào chắn và biển cảnh báo","Bơm nước nếu có nguy cơ ngập","Kiểm tra đất nền mỗi ca"],
    chemical:           ["Có MSDS cho tất cả hóa chất","PPE đầy đủ (găng, kính, mặt nạ)","Khu vực thông thoáng","Hộp sơ cứu và vòi rửa mắt","Xử lý chất thải đúng quy định"],
    other:              ["Đánh giá rủi ro JSA đã hoàn thành","PPE phù hợp theo công việc","Người giám sát được chỉ định","Phương án ứng phó khẩn cấp"],
  };

  // PTW checklist state
  const [ptwChecklist, setPtwChecklist] = React.useState<Record<string, boolean>>({});

  const [ptws, setPtws]           = React.useState([]);
  const [toolboxTalks, setToolboxTalks] = React.useState([]);
  const [showPTWForm, setShowPTWForm]   = React.useState(false);
  const [showToolboxForm, setShowToolboxForm] = React.useState(false);
  const [ptwForm, setPtwForm] = React.useState<Partial<PTW>>({
    type: 'hot_work', status: 'draft',
    start_date: new Date().toLocaleDateString('vi-VN'),
    end_date: new Date().toLocaleDateString('vi-VN'),
    created_at: new Date().toLocaleDateString('vi-VN'),
  });
  const [toolboxForm, setToolboxForm] = React.useState<Partial<ToolboxTalk>>({
    date: new Date().toLocaleDateString('vi-VN'),
    created_at: new Date().toLocaleDateString('vi-VN'),
    attendees_count: 0,
  });

  // Worker certificates
  interface WorkerCert {
    id:string; worker_name:string; contractor:string;
    cert_type:string; cert_no:string;
    issued:string; expiry:string; issued_by:string;
  }
  const [workerCerts, setWorkerCerts]   = React.useState([]);
  const [showCertForm, setShowCertForm] = React.useState(false);
  const [certForm, setCertForm]         = React.useState<Partial<WorkerCert>>({});
  const [certSearch, setCertSearch]     = React.useState('');
  const [certFilter, setCertFilter]     = React.useState<'all'|'valid'|'expiring'|'expired'>('all');
  const [incidents, setIncidents]     = React.useState([]);
  const [trainings, setTrainings]     = React.useState([]);
  const [violations, setViolations]   = React.useState([]);
  const [inspections, setInspections] = React.useState([]);

  // ── Load from db on mount ──────────────────────────────────────
  React.useEffect(() => {
    const pid = selectedProject?.id || projectId || 'default';
    db.get<Incident[]>('hse_incidents', pid, []).then(setIncidents);
    db.get<Training[]>('hse_trainings', pid, []).then(setTrainings);
    db.get<Violation[]>('hse_violations', pid, []).then(setViolations);
    db.get<Inspection[]>('hse_inspections', pid, []).then(setInspections);
    db.get<WorkerCert[]>('hse_worker_certs', pid, []).then(setWorkerCerts);
    db.get<PTW[]>('hse_ptws', pid, []).then(setPtws);
    db.get<ToolboxTalk[]>('hse_toolbox', pid, []).then(setToolboxTalks);
  }, [selectedProject?.id, projectId]);

  // ── Realtime sync ──────────────────────────────────────────────────────────
  const _hse_pid = selectedProject?.id || projectId || 'default';
  useRealtimeSync(_hse_pid, ['hse_incidents', 'hse_trainings', 'hse_violations', 'hse_inspections', 'hse_worker_certs', 'hse_ptws', 'hse_toolbox'], async () => {
    const pid = selectedProject?.id || projectId || 'default';
    const [inc, trn, vio, ins, crt, pw, tb] = await Promise.all([
      db.get<Incident[]>('hse_incidents', pid, []),
      db.get<Training[]>('hse_trainings', pid, []),
      db.get<Violation[]>('hse_violations', pid, []),
      db.get<Inspection[]>('hse_inspections', pid, []),
      db.get<WorkerCert[]>('hse_worker_certs', pid, []),
      db.get<PTW[]>('hse_ptws', pid, []),
      db.get<ToolboxTalk[]>('hse_toolbox', pid, []),
    ]);
    setIncidents(inc); setTrainings(trn); setViolations(vio);
    setInspections(ins); setWorkerCerts(crt);
    setPtws(pw); setToolboxTalks(tb);
  });

  // Forms
  const [showIncidentForm, setShowIncidentForm] = React.useState(false);
  const [showCamera, setShowCamera] = React.useState(false);
  const [incidentPhotos, setIncidentPhotos] = React.useState<CaptureResult[]>([]);
  const [hseAnalysis, setHseAnalysis] = React.useState<HSEAnalysisResult | null>(null);

  // gem:open-action — WorkspaceActionBar trigger
  React.useEffect(() => {
    const handler = (e: Event) => {
      const { actionId } = (e as CustomEvent).detail;
      if (actionId === 'HSE_INCIDENT')   { setHseTab('incidents'); setTimeout(() => setShowIncidentForm(true), 150); }
      if (actionId === 'PERMIT_TO_WORK') { setHseTab('ptw'); setTimeout(() => setShowPTWForm(true), 150); }
      if (actionId === 'CAPA')           { setHseTab('violations'); setTimeout(() => setShowViolationForm(true), 150); }
      if (actionId === 'HSE_INSPECTION')  { setHseTab('inspections');  setTimeout(() => setShowIncidentForm(true), 150); }
    };
    window.addEventListener('gem:open-action', handler);
    return () => window.removeEventListener('gem:open-action', handler);
  }, []);
  const [showTrainingForm, setShowTrainingForm] = React.useState(false);
  const [showViolationForm, setShowViolationForm] = React.useState(false);
  const [showInspectionForm, setShowInspectionForm] = React.useState(false);
  const [selectedIncident, setSelectedIncident] = React.useState<Incident|null>(null);
  const [gemReportLoading, setGemReportLoading] = React.useState(false);
  const [gemReport, setGemReport]               = React.useState('');

  // Form state — incidents
  const [incForm, setIncForm] = React.useState<Partial<Incident>>({ level:'minor', status:'open', date: new Date().toLocaleDateString('vi-VN') });
  const [vioForm, setVioForm] = React.useState<Partial<Violation>>({ level:'nhe', status:'open', fine_amount:0, date: new Date().toLocaleDateString('vi-VN') });
  const [traForm, setTraForm] = React.useState<Partial<Training>>({ status:'scheduled', duration_hours:4, max_participants:30, certificate_expiry_months:12 });

  // ── Computed KPIs ─────────────────────────────────────────────
  const today = new Date();
  const thisMonth = today.getMonth();
  const openIncidents = incidents.filter(i => i.status !== 'closed').length;
  const majorIncidents = incidents.filter(i => ['major','fatal'].includes(i.level)).length;
  const daysSafe = (() => {
    const lastMajor = incidents.filter(i => ['minor','medium','major','fatal'].includes(i.level))
      .sort((a,b) => b.date.localeCompare(a.date))[0];
    if (!lastMajor) return 145;
    const d = lastMajor.date.split('/').reverse().join('-');
    return Math.max(0, Math.round((today.getTime() - new Date(d).getTime()) / 86400000));
  })();
  const overdueTrainings = trainings.filter(t => t.status === 'overdue').length;
  const openViolations   = violations.filter(v => v.status === 'open').length;
  const totalFines       = violations.reduce((s,v) => s + (v.fine_amount||0), 0);
  const lastInspection   = inspections[0];
  const failItems        = lastInspection?.checklist_items.filter(c => c.result === 'fail').length || 0;

  // ── Helpers ──────────────────────────────────────────────────
  const incidentLevelCfg:Record<IncidentLevel,{label:string;color:string;bg:string}> = {
    near_miss:  { label:'Suýt xảy ra', color:'text-slate-600',  bg:'bg-slate-100'   },
    minor:      { label:'Nhẹ',          color:'text-amber-700',  bg:'bg-amber-100'   },
    medium:     { label:'Trung bình',   color:'text-orange-700', bg:'bg-orange-100'  },
    major:      { label:'Nghiêm trọng', color:'text-rose-700',   bg:'bg-rose-100'    },
    fatal:      { label:'Tử vong',      color:'text-rose-900',   bg:'bg-rose-200'    },
  };
  const violationLevelCfg:Record<ViolationLevel,{label:string;color:string;bg:string}> = {
    nhe:           { label:'Nhắc nhở',      color:'text-amber-700',  bg:'bg-amber-100'  },
    trung:         { label:'Cảnh cáo',      color:'text-orange-700', bg:'bg-orange-100' },
    nghiem_trong:  { label:'Nghiêm trọng',  color:'text-rose-700',   bg:'bg-rose-100'   },
  };
  const trainingStatusCfg:Record<TrainingStatus,{label:string;color:string;bg:string}> = {
    scheduled: { label:'Sắp diễn ra', color:'text-blue-700',    bg:'bg-blue-100'    },
    ongoing:   { label:'Đang diễn ra', color:'text-emerald-700', bg:'bg-emerald-100' },
    completed: { label:'Hoàn thành',   color:'text-slate-600',   bg:'bg-slate-100'   },
    overdue:   { label:'Quá hạn',      color:'text-rose-700',    bg:'bg-rose-100'    },
  };
  const _pid = selectedProject?.id || projectId || 'default';
  const saveHSE = <T,>(collection:string, data:T[]) => { db.set(collection, _pid, data); };

  // ── GEM HSE Report ─────────────────────────────────────────────
  const generateHSEReport = async () => {
    setGemReportLoading(true); setGemReport('');
    try {
      const model = genAI.getGenerativeModel({ model: GEM_MODEL,
        systemInstruction:`Bạn là GEM — chuyên gia HSE xây dựng. Xưng "em", gọi "Anh/Chị". Giọng nữ miền Nam, thân thiện nhưng nghiêm túc về an toàn. Viết báo cáo ngắn gọn, có số liệu cụ thể, có khuyến nghị ưu tiên.` });
      const r = await model.generateContent(
        `Tạo báo cáo tóm tắt HSE tháng cho dự án ${selectedProject.name}:\n\nKPI:\n- Số ngày an toàn liên tục: ${daysSafe} ngày\n- Sự cố/tai nạn: ${incidents.length} vụ (${openIncidents} chưa đóng)\n- Vi phạm: ${violations.length} lượt (${openViolations} chưa xử lý)\n- Huấn luyện quá hạn: ${overdueTrainings} khóa\n- Kiểm tra gần nhất: ${lastInspection?.date} — ${lastInspection?.overall === 'fail' ? 'Không đạt' : lastInspection?.overall === 'pass' ? 'Đạt' : 'Đạt có điều kiện'}\n- Tổng tiền phạt: ${totalFines.toLocaleString('vi-VN')} nghìn đồng\n\nSự cố gần nhất: ${incidents[0]?.description || 'Không có'}\nVi phạm nghiêm trọng: ${violations.filter(v=>v.level==='nghiem_trong').length} vụ\n\nHãy viết:\n1. Tóm tắt tình hình an toàn tháng (3-4 câu)\n2. Điểm nổi bật tích cực\n3. Vấn đề cần cải thiện ngay (ưu tiên)\n4. Khuyến nghị hành động tuần tới\nViết bằng tiếng Việt, chuyên nghiệp, có thể dùng làm báo cáo gửi Ban Giám đốc.`
      );
      setGemReport(r.response.text());
    } catch { setGemReport('Dạ em chưa kết nối được GEM lúc này, Anh/Chị thử lại sau nhé.'); }
    finally { setGemReportLoading(false); }
  };

  // ══════════════════════════════════════════════════════════════
  // RENDER
  // ══════════════════════════════════════════════════════════════
  return (
    <div className="space-y-4 animate-in fade-in duration-300">

      {/* HSE Sub-tab bar + Approval button */}
      <div className="flex gap-1.5 flex-wrap bg-white border border-slate-200 rounded-2xl p-2 items-center">
        {/* Approval queue badge */}
        <button
          onClick={() => setShowApprovalPanel(true)}
          className="relative ml-auto flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-amber-50 border border-amber-200 text-amber-700 hover:bg-amber-100 transition-all"
        >
          <ClipboardList size={13}/> Hàng duyệt HSE
          {hseApprovalQueue.length > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
              {hseApprovalQueue.length}
            </span>
          )}
        </button>
      </div>
      <div className="flex gap-1.5 flex-wrap bg-white border border-slate-200 rounded-2xl p-2">
        {([
          { id:'dashboard',   label:'Tổng quan',      icon:<LayoutDashboard size={13}/>,  color:'rose'    },
          { id:'ptw',         label:'PTW / Giấy phép', icon:<ClipboardList size={13}/>,    color:'violet'  },
          { id:'incidents',   label:'Sự cố / TNLĐ',  icon:<AlertTriangle size={13}/>,    color:'rose'    },
          { id:'violations',  label:'Vi phạm',        icon:<ShieldAlert size={13}/>,      color:'orange'  },
          { id:'trainings',   label:'Huấn luyện AT',  icon:<GraduationCap size={13}/>,    color:'blue'    },
          { id:'inspections', label:'Kiểm tra định kỳ',icon:<ClipboardList size={13}/>,   color:'teal'    },
          { id:'reports',     label:'Báo cáo GEM',    icon:<Sparkles size={13}/>,         color:'emerald' },
        ] as {id:string;label:string;icon:React.ReactNode;color:string}[]).map(t => (
          <button key={t.id} onClick={() => setHseTab(t.id as any)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
              hseTab === t.id
                ? t.color==='rose'    ? 'bg-rose-600 text-white shadow-sm'
                : t.color==='orange'  ? 'bg-orange-500 text-white shadow-sm'
                : t.color==='blue'    ? 'bg-blue-600 text-white shadow-sm'
                : t.color==='teal'    ? 'bg-teal-600 text-white shadow-sm'
                : t.color==='violet'  ? 'bg-violet-600 text-white shadow-sm'
                                      : 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}>
            {t.icon}{t.label}
            {t.id==='incidents'  && openIncidents > 0   && <span className="bg-white/30 text-[9px] font-bold px-1.5 rounded-full">{openIncidents}</span>}
            {t.id==='violations' && openViolations > 0  && <span className="bg-white/30 text-[9px] font-bold px-1.5 rounded-full">{openViolations}</span>}
            {t.id==='trainings'  && overdueTrainings > 0 && <span className="bg-white/30 text-[9px] font-bold px-1.5 rounded-full">{overdueTrainings}</span>}
            {t.id==='ptw'        && ptws.filter(p=>p.status==='pending').length > 0 && <span className="bg-white/30 text-[9px] font-bold px-1.5 rounded-full">{ptws.filter(p=>p.status==='pending').length}</span>}
          </button>
        ))}
      </div>

      {/* ── DASHBOARD ──────────────────────────────────────────── */}
      {hseTab === 'dashboard' && (
        <div className="space-y-4">
          {/* KPI Strip */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label:'Ngày an toàn', val:String(daysSafe), unit:'ngày', icon:<ShieldCheck size={18}/>, color:'emerald', alert: daysSafe < 30 },
              { label:'Sự cố mở', val:String(openIncidents), unit:'vụ', icon:<AlertTriangle size={18}/>, color:'rose', alert: openIncidents > 0 },
              { label:'Vi phạm chờ xử lý', val:String(openViolations), unit:'lượt', icon:<ShieldAlert size={18}/>, color:'orange', alert: openViolations > 0 },
              { label:'Huấn luyện quá hạn', val:String(overdueTrainings), unit:'khóa', icon:<GraduationCap size={18}/>, color:'amber', alert: overdueTrainings > 0 },
            ].map(k => (
              <div key={k.label} className={`bg-white border rounded-2xl p-4 flex items-center gap-3 transition-all ${k.alert ? 'border-rose-200 bg-rose-50/40 shadow-sm' : 'border-slate-200'}`}>
                <div className={`p-2.5 rounded-xl shrink-0 ${
                  k.color==='emerald' ? 'bg-emerald-100 text-emerald-600' :
                  k.color==='rose'    ? 'bg-rose-100 text-rose-600' :
                  k.color==='orange'  ? 'bg-orange-100 text-orange-600' :
                                        'bg-amber-100 text-amber-600'
                }`}>{k.icon}</div>
                <div>
                  <p className="text-[10px] text-slate-400 font-semibold leading-none mb-0.5">{k.label}</p>
                  <p className="text-xl font-bold text-slate-800 leading-none">{k.val} <span className="text-xs font-normal text-slate-400">{k.unit}</span></p>
                </div>
              </div>
            ))}
          </div>

          {/* Alerts row */}
          {(openIncidents > 0 || openViolations > 0 || overdueTrainings > 0 || failItems > 0) && (
            <div className="space-y-2">
              {openIncidents > 0 && (
                <div onClick={() => setHseTab('incidents')} className="flex items-center gap-3 bg-rose-50 border border-rose-200 rounded-xl px-4 py-3 text-sm text-rose-800 cursor-pointer hover:bg-rose-100 transition-colors">
                  <AlertTriangle size={14} className="text-rose-500 shrink-0"/>
                  <span><strong>{openIncidents} sự cố</strong> chưa đóng — cần cập nhật biện pháp khắc phục</span>
                  <ChevronRight size={14} className="ml-auto text-rose-400"/>
                </div>
              )}
              {overdueTrainings > 0 && (
                <div onClick={() => setHseTab('trainings')} className="flex items-center gap-3 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 text-sm text-amber-800 cursor-pointer hover:bg-amber-100 transition-colors">
                  <GraduationCap size={14} className="text-amber-500 shrink-0"/>
                  <span><strong>{overdueTrainings} khóa huấn luyện</strong> quá hạn — cần sắp xếp lại lịch</span>
                  <ChevronRight size={14} className="ml-auto text-amber-400"/>
                </div>
              )}
              {failItems > 0 && (
                <div onClick={() => setHseTab('inspections')} className="flex items-center gap-3 bg-orange-50 border border-orange-200 rounded-xl px-4 py-3 text-sm text-orange-800 cursor-pointer hover:bg-orange-100 transition-colors">
                  <ClipboardList size={14} className="text-orange-500 shrink-0"/>
                  <span>Kiểm tra <strong>{lastInspection?.date}</strong> có <strong>{failItems} hạng mục không đạt</strong> — cần khắc phục trước {lastInspection?.next_date}</span>
                  <ChevronRight size={14} className="ml-auto text-orange-400"/>
                </div>
              )}
            </div>
          )}

          {/* 2-col: Sự cố gần nhất + Training upcoming */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <p className="text-xs font-bold text-slate-700 flex items-center gap-1.5"><AlertTriangle size={12} className="text-rose-500"/> Sự cố gần đây</p>
                <button onClick={() => setHseTab('incidents')} className="text-[10px] text-emerald-600 font-semibold hover:underline">Xem tất cả</button>
              </div>
              <div className="divide-y divide-slate-100">
                {incidents.slice(0,3).map(inc => (
                  <div key={inc.id} className="px-4 py-3 flex items-start gap-3 hover:bg-slate-50 transition-colors cursor-pointer" onClick={() => setSelectedIncident(inc)}>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg shrink-0 mt-0.5 ${incidentLevelCfg[inc.level].bg} ${incidentLevelCfg[inc.level].color}`}>
                      {incidentLevelCfg[inc.level].label}
                    </span>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-700 line-clamp-1">{inc.description}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{inc.date} · {inc.location}</p>
                    </div>
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full shrink-0 ${inc.status==='closed'?'bg-slate-100 text-slate-500':inc.status==='investigating'?'bg-amber-100 text-amber-700':'bg-rose-100 text-rose-700'}`}>
                      {inc.status==='closed'?'Đã đóng':inc.status==='investigating'?'Đang xử lý':'Mở'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <p className="text-xs font-bold text-slate-700 flex items-center gap-1.5"><GraduationCap size={12} className="text-blue-500"/> Lịch huấn luyện</p>
                <button onClick={() => setHseTab('trainings')} className="text-[10px] text-emerald-600 font-semibold hover:underline">Xem tất cả</button>
              </div>
              <div className="divide-y divide-slate-100">
                {trainings.slice(0,4).map(t => (
                  <div key={t.id} className="px-4 py-3 flex items-center gap-3 hover:bg-slate-50 transition-colors">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg shrink-0 ${trainingStatusCfg[t.status].bg} ${trainingStatusCfg[t.status].color}`}>
                      {trainingStatusCfg[t.status].label}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-700 truncate">{t.title}</p>
                      <p className="text-[10px] text-slate-400">{t.scheduled_date} · {t.duration_hours}h · {t.trainer}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Camera AI + vi phạm recent */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-rose-50 to-orange-50 border border-rose-200 rounded-2xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-rose-600 rounded-xl flex items-center justify-center shrink-0">
                  <Camera size={15} className="text-white"/>
                </div>
                <div>
                  <p className="text-xs font-bold text-rose-800">GEM Camera AI</p>
                  <p className="text-[10px] text-rose-600">Phát hiện vi phạm PPE tự động</p>
                </div>
              </div>
              <div className="bg-white/60 border border-rose-200 border-dashed rounded-xl p-4 text-center">
                <UploadCloud size={20} className="text-rose-400 mx-auto mb-1.5"/>
                <p className="text-xs font-medium text-rose-800">Tải ảnh hiện trường lên</p>
                <p className="text-[10px] text-rose-600 mt-0.5">GEM sẽ phát hiện: thiếu mũ BH, thiếu áo phản quang, vào vùng cấm</p>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <p className="text-xs font-bold text-slate-700 flex items-center gap-1.5"><ShieldAlert size={12} className="text-orange-500"/> Vi phạm gần đây</p>
                <button onClick={() => setHseTab('violations')} className="text-[10px] text-emerald-600 font-semibold hover:underline">Xem tất cả</button>
              </div>
              <div className="divide-y divide-slate-100">
                {violations.slice(0,3).map(v => (
                  <div key={v.id} className="px-4 py-3 flex items-center gap-3 hover:bg-slate-50 transition-colors">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg shrink-0 ${violationLevelCfg[v.level].bg} ${violationLevelCfg[v.level].color}`}>
                      {violationLevelCfg[v.level].label}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-700 truncate">{v.worker} · {v.contractor}</p>
                      <p className="text-[10px] text-slate-400 truncate">{v.description}</p>
                    </div>
                    {v.recurrence && <span className="text-[9px] font-bold bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded shrink-0">Tái phạm</span>}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── PTW / PERMIT TO WORK ───────────────────────────────── */}
      {hseTab === 'ptw' && (
        <div className="space-y-5">
          {/* Header row */}
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex gap-2 flex-wrap">
              {(['pending','active','approved','closed'] as PTWStatus[]).map(s => {
                const cnt = ptws.filter(p => p.status === s).length;
                if (!cnt) return null;
                return <span key={s} className={`text-xs font-semibold px-3 py-1.5 rounded-xl border ${PTW_STATUS_CFG[s].cls}`}>{PTW_STATUS_CFG[s].label}: {cnt}</span>;
              })}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowToolboxForm(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-blue-50 border border-blue-200 text-blue-700 rounded-xl text-xs font-bold hover:bg-blue-100 transition-colors">
                <MessageCircle size={13}/> Toolbox Talk
              </button>
              <button onClick={() => setShowPTWForm(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-violet-600 text-white rounded-xl text-xs font-bold hover:bg-violet-700 transition-colors">
                <Plus size={13}/> Tạo Giấy phép
              </button>
            </div>
          </div>

          {/* PTW list */}
          <div className="space-y-3">
            {ptws.length === 0 && (
              <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center text-sm text-slate-400">Chưa có giấy phép nào</div>
            )}
            {ptws.map(p => (
              <div key={p.id} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${PTW_STATUS_CFG[p.status].cls}`}>{PTW_STATUS_CFG[p.status].label}</span>
                      <span className="text-[10px] font-semibold bg-violet-100 text-violet-700 px-2 py-0.5 rounded-full">{PTW_TYPE_LABEL[p.type]}</span>
                    </div>
                    <p className="text-sm font-bold text-slate-800">{p.title}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{p.area} · {p.contractor} · {p.requester}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{p.start_date} → {p.end_date}</p>
                    {p.hazards && <p className="text-xs text-amber-700 bg-amber-50 rounded-lg px-2 py-1 mt-2">⚠ {p.hazards}</p>}
                    {p.approved_by && <p className="text-[10px] text-emerald-600 mt-1">✅ Duyệt bởi {p.approved_by} lúc {p.approved_at}</p>}
                    {p.status === "active" && p.end_date && (
                      <div className="mt-2 flex items-center gap-1.5 text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-2 py-1">
                        <Clock size={10}/>
                        Hiệu lực đến: {p.end_date} — đang hoạt động
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col gap-1.5 shrink-0">
                    {p.status === 'pending' && (
                      <button onClick={() => {
                        setPtws(prev => {
                          const next = prev.map(x => x.id === p.id ? {
                            ...x, status: 'approved' as PTWStatus,
                            approved_by: ctx.userId || 'HSE Officer',
                            approved_at: new Date().toLocaleString('vi-VN'),
                          } : x);
                          db.set('hse_ptws', _hse_pid, next);
                          return next;
                        });
                      }} className="px-3 py-1.5 bg-emerald-500 text-white rounded-xl text-[10px] font-bold hover:bg-emerald-600">
                        ✅ Duyệt
                      </button>
                    )}
                    {p.status === 'approved' && (
                      <button onClick={() => {
                        setPtws(prev => {
                          const next = prev.map(x => x.id === p.id ? {...x, status: 'active' as PTWStatus} : x);
                          db.set('hse_ptws', _hse_pid, next);
                          return next;
                        });
                      }} className="px-3 py-1.5 bg-blue-500 text-white rounded-xl text-[10px] font-bold hover:bg-blue-600">
                        ▶ Kích hoạt
                      </button>
                    )}
                    {(p.status === 'active' || p.status === 'approved') && (
                      <button onClick={() => {
                        setPtws(prev => {
                          const next = prev.map(x => x.id === p.id ? {...x, status: 'closed' as PTWStatus} : x);
                          db.set('hse_ptws', _hse_pid, next);
                          return next;
                        });
                      }} className="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-xl text-[10px] font-bold hover:bg-slate-200">
                        Đóng
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Toolbox Talk list */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2"><MessageCircle size={14} className="text-blue-600"/>Toolbox Talk — {toolboxTalks.length} buổi</h3>
            </div>
            <div className="divide-y divide-slate-100">
              {toolboxTalks.map(tb => (
                <div key={tb.id} className="px-4 py-3 flex items-start gap-3 hover:bg-slate-50/50">
                  <div className="w-8 h-8 rounded-xl bg-blue-100 flex items-center justify-center shrink-0 text-blue-600"><MessageCircle size={14}/></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-800">{tb.topic}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">{tb.date} · {tb.area} · {tb.conducted_by} · {tb.attendees_count} người</p>
                    <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">{tb.key_points}</p>
                  </div>
                </div>
              ))}
              {toolboxTalks.length === 0 && <div className="px-4 py-6 text-center text-xs text-slate-400">Chưa có buổi nào</div>}
            </div>
          </div>

        </div>
      )}

      {/* ── INCIDENTS ─────────────────────────────────────────── */}
      {hseTab === 'incidents' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm font-bold text-slate-700">{incidents.length} sự cố được ghi nhận</p>
            <button onClick={() => setShowIncidentForm(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-colors">
              <Plus size={13}/> Ghi nhận sự cố
            </button>
          </div>

          {/* Incident detail modal */}
          {selectedIncident && (
            <div className="fixed inset-0 z-[150] flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4" onClick={() => setSelectedIncident(null)}>
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 animate-in zoom-in-95 duration-200" onClick={e=>e.stopPropagation()}>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg ${incidentLevelCfg[selectedIncident.level].bg} ${incidentLevelCfg[selectedIncident.level].color}`}>
                      {incidentLevelCfg[selectedIncident.level].label}
                    </span>
                    <h3 className="text-base font-bold text-slate-800 mt-2 leading-snug">{selectedIncident.description}</h3>
                  </div>
                  <button onClick={() => setSelectedIncident(null)}><X size={16} className="text-slate-400"/></button>
                </div>
                <div className="space-y-2 text-sm">
                  {[
                    ['📅 Thời gian',     `${selectedIncident.date} ${selectedIncident.time}`],
                    ['📍 Vị trí',        selectedIncident.location],
                    ['👤 Người bị nạn',  selectedIncident.injured || 'Không có'],
                    ['🔍 Nguyên nhân',   selectedIncident.root_cause],
                    ['✅ Biện pháp',     selectedIncident.action],
                    ['📋 Người báo cáo', selectedIncident.reporter],
                  ].map(([k,v]) => (
                    <div key={k} className="flex gap-3 py-1.5 border-b border-slate-100">
                      <span className="text-xs text-slate-400 w-32 shrink-0">{k}</span>
                      <span className="text-xs text-slate-700 font-medium">{v}</span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between items-center mt-4">
                  <select defaultValue={selectedIncident.status} onChange={e => {
                    const updated = incidents.map(i => i.id === selectedIncident.id ? {...i, status:e.target.value as any} : i);
                    setIncidents(updated); saveHSE('hse_incidents', updated);
                    setSelectedIncident({...selectedIncident, status:e.target.value as any});
                  }} className="text-xs border border-slate-200 rounded-xl px-3 py-2 focus:outline-none">
                    <option value="open">Mở</option>
                    <option value="investigating">Đang điều tra</option>
                    <option value="closed">Đã đóng</option>
                  </select>
                  <button onClick={() => setSelectedIncident(null)} className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold">Đóng</button>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {incidents.map(inc => (
              <div key={inc.id} onClick={() => setSelectedIncident(inc)}
                className="bg-white border border-slate-200 rounded-2xl p-4 flex items-start gap-3 hover:shadow-md hover:border-rose-200 transition-all cursor-pointer group">
                <span className={`text-[10px] font-bold px-2 py-1 rounded-xl shrink-0 ${incidentLevelCfg[inc.level].bg} ${incidentLevelCfg[inc.level].color}`}>
                  {incidentLevelCfg[inc.level].label}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-slate-700 group-hover:text-rose-700 transition-colors line-clamp-1">{inc.description}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{inc.date} {inc.time} · {inc.location} · Báo cáo: {inc.reporter}</p>
                  {inc.injured && <p className="text-[10px] text-rose-600 font-semibold mt-0.5">⚠ Người bị nạn: {inc.injured}</p>}
                </div>
                <span className={`text-[9px] font-bold px-2 py-1 rounded-full shrink-0 ${
                  inc.status==='closed'?'bg-slate-100 text-slate-500':inc.status==='investigating'?'bg-amber-100 text-amber-700':'bg-rose-100 text-rose-700'
                }`}>{inc.status==='closed'?'Đã đóng':inc.status==='investigating'?'Đang xử lý':'Mở'}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── VIOLATIONS ────────────────────────────────────────── */}
      {hseTab === 'violations' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm font-bold text-slate-700">{violations.length} vi phạm được ghi nhận</p>
              <p className="text-xs text-slate-500">Tổng tiền phạt: <span className="font-bold text-orange-600">{totalFines.toLocaleString('vi-VN')}K đồng</span> · Tái phạm: {violations.filter(v=>v.recurrence).length} người</p>
            </div>
            <button onClick={() => setShowViolationForm(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition-colors">
              <Plus size={13}/> Ghi vi phạm
            </button>
          </div>


          <div className="space-y-2">
            {violations.map(v => (
              <div key={v.id} className={`bg-white border rounded-2xl p-4 flex items-start gap-3 hover:shadow-sm transition-all ${v.status==='open'?'border-orange-200':'border-slate-200'}`}>
                <span className={`text-[10px] font-bold px-2 py-1 rounded-xl shrink-0 ${violationLevelCfg[v.level].bg} ${violationLevelCfg[v.level].color}`}>
                  {violationLevelCfg[v.level].label}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="text-sm font-bold text-slate-700">{v.worker}</p>
                    <span className="text-[10px] text-slate-400">·</span>
                    <p className="text-xs text-slate-500">{v.contractor}</p>
                    {v.recurrence && <span className="text-[9px] font-bold bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded">🔁 Tái phạm</span>}
                  </div>
                  <p className="text-xs text-slate-600">{v.description}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{v.date} · {v.action}{v.fine_amount > 0 ? ` · Phạt: ${v.fine_amount.toLocaleString('vi-VN')}K` : ''}</p>
                </div>
                <button onClick={() => {
                  const updated = violations.map(x => x.id === v.id ? {...x, status: x.status==='open'?'resolved':'open'} : x) as Violation[];
                  setViolations(updated); saveHSE('hse_violations', updated);
                }} className={`text-[9px] font-bold px-2 py-1 rounded-full shrink-0 cursor-pointer transition-colors ${v.status==='open'?'bg-orange-100 text-orange-700 hover:bg-orange-200':'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                  {v.status==='open'?'Chờ xử lý':'Đã xử lý'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {hseTab === 'trainings' && (
        <div className="space-y-4">
          {/* Toggle: Khóa học vs Chứng chỉ cá nhân */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-slate-700">{trainings.length} khóa huấn luyện</p>
              <p className="text-xs text-slate-500">{trainings.filter(t=>t.status==='completed').length} hoàn thành · {overdueTrainings} quá hạn · {trainings.filter(t=>t.status==='scheduled').length} sắp diễn ra</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex bg-slate-100 rounded-xl p-0.5 border border-slate-200">
                <button
                  onClick={() => setTrainingView('classes')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${trainingView==='classes' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  ?? Khóa học
                </button>
                <button
                  onClick={() => setTrainingView('certs')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${trainingView==='certs' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  ?? Chứng chỉ cá nhân
                </button>
              </div>
              {trainingView === 'classes' && (
                <button onClick={() => setShowTrainingForm(true)}
                  className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors">
                  <Plus size={13}/> Thêm khóa học
                </button>
              )}
              {trainingView === 'certs' && (
                <button onClick={() => setShowCertForm(true)}
                  className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors">
                  <Plus size={13}/> Thêm chứng chỉ
                </button>
              )}
            </div>
          </div>

          {/* ── VIEW: KHÓA HỌC ── */}
          {trainingView === 'classes' && (
            <div className="space-y-3">
              <div className="space-y-2">
                {trainings.map(t => {
                  const passPct = t.pass_count && t.max_participants ? Math.round(t.pass_count/t.max_participants*100) : 0;
                  return (
                    <div key={t.id} className={`bg-white border rounded-2xl p-4 hover:shadow-sm transition-all ${t.status==='overdue'?'border-rose-200 bg-rose-50/20':t.status==='scheduled'?'border-blue-200':'border-slate-200'}`}>
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg ${trainingStatusCfg[t.status].bg} ${trainingStatusCfg[t.status].color}`}>
                              {trainingStatusCfg[t.status].label}
                            </span>
                            <span className="text-[10px] text-slate-400">{t.type}</span>
                          </div>
                          <p className="text-sm font-bold text-slate-700">{t.title}</p>
                          <p className="text-[10px] text-slate-400">{t.scheduled_date} · {t.duration_hours}h · {t.trainer} · Tối đa {t.max_participants} người</p>
                        </div>
                        {t.status === 'completed' && (
                          <div className="text-right shrink-0">
                            <p className="text-sm font-bold text-emerald-600">{t.pass_count}/{t.max_participants}</p>
                            <p className="text-[10px] text-slate-400">đạt ({passPct}%)</p>
                          </div>
                        )}
                      </div>
                      {t.status === 'completed' && (
                        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 rounded-full" style={{width:`${passPct}%`}}/>
                        </div>
                      )}
                      {t.notes && <p className="text-[10px] text-slate-500 mt-2 italic">{t.notes}</p>}
                      {t.status !== 'completed' && (
                        <button onClick={() => {
                          const updated = trainings.map(x => x.id===t.id ? {...x,status:'completed',pass_count:Math.round(x.max_participants*0.95)} : x) as Training[];
                          setTrainings(updated); saveHSE('hse_trainings', updated);
                        }} className="mt-2 text-[10px] font-semibold text-blue-600 hover:underline">
                          → Đánh dấu hoàn thành
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── VIEW: CHỨNG CHỈ CÁ NHÂN ── */}
          {trainingView === 'certs' && (
            <div className="space-y-3">
              {/* Cảnh báo hết hạn */}
              {workerCerts.filter(c => {
                const exp = new Date(c.expiry.split('/').reverse().join('-'));
                const diff = Math.floor((exp.getTime() - Date.now()) / 86400000);
                return diff <= 30 && diff >= 0;
              }).length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-center gap-2">
                  <AlertTriangle size={14} className="text-amber-600 shrink-0"/>
                  <p className="text-xs text-amber-800 font-medium">
                    {workerCerts.filter(c => {
                      const exp = new Date(c.expiry.split('/').reverse().join('-'));
                      return Math.floor((exp.getTime()-Date.now())/86400000) <= 30;
                    }).length} chứng chỉ sắp hết hạn trong 30 ngày
                  </p>
                </div>
              )}

              {/* Form thêm chứng chỉ */}

              {/* Bộ lọc */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                  <input value={certSearch} onChange={e=>setCertSearch(e.target.value)}
                    placeholder="Tìm tên, tổ đội, loại chứng chỉ..."
                    className="w-full pl-8 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-400"/>
                </div>
                <select value={certFilter} onChange={e=>setCertFilter(e.target.value as any)}
                  className="text-xs border border-slate-200 rounded-xl px-3 py-2 bg-white focus:outline-none">
                  <option value="all">Tất cả</option>
                  <option value="valid">Còn hạn</option>
                  <option value="expiring">Sắp hết hạn (30 ngày)</option>
                  <option value="expired">Đã hết hạn</option>
                </select>
              </div>

              {/* Danh sách chứng chỉ */}
              <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-4 py-3 text-left font-bold text-slate-500 uppercase tracking-wider text-[10px]">Họ và tên</th>
                      <th className="px-4 py-3 text-left font-bold text-slate-500 uppercase tracking-wider text-[10px]">Loại chứng chỉ</th>
                      <th className="px-4 py-3 text-left font-bold text-slate-500 uppercase tracking-wider text-[10px] hidden md:table-cell">Số CC / Nơi cấp</th>
                      <th className="px-4 py-3 text-left font-bold text-slate-500 uppercase tracking-wider text-[10px]">Hết hạn</th>
                      <th className="px-4 py-3 text-left font-bold text-slate-500 uppercase tracking-wider text-[10px]">Trạng thái</th>
                      <th className="px-4 py-3 text-[10px]"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {workerCerts
                      .filter(c => {
                        const q = certSearch.toLowerCase();
                        const matchSearch = !q || c.worker_name.toLowerCase().includes(q) || c.contractor.toLowerCase().includes(q) || c.cert_type.toLowerCase().includes(q);
                        const exp = new Date(c.expiry.split('/').reverse().join('-'));
                        const diff = Math.floor((exp.getTime()-Date.now())/86400000);
                        const matchFilter = certFilter==='all' || (certFilter==='valid'&&diff>30) || (certFilter==='expiring'&&diff<=30&&diff>=0) || (certFilter==='expired'&&diff<0);
                        return matchSearch && matchFilter;
                      })
                      .map(c => {
                        const exp = new Date(c.expiry.split('/').reverse().join('-'));
                        const diff = Math.floor((exp.getTime()-Date.now())/86400000);
                        const isExpired = diff < 0;
                        const isExpiring = diff >= 0 && diff <= 30;
                        return (
                          <tr key={c.id} className={`hover:bg-slate-50 transition-colors ${isExpired?'bg-rose-50/30':isExpiring?'bg-amber-50/30':''}`}>
                            <td className="px-4 py-3">
                              <p className="font-bold text-slate-800">{c.worker_name}</p>
                              <p className="text-[10px] text-slate-400">{c.contractor}</p>
                            </td>
                            <td className="px-4 py-3 font-medium text-slate-700">{c.cert_type}</td>
                            <td className="px-4 py-3 text-slate-500 hidden md:table-cell">
                              <p>{c.cert_no || '—'}</p>
                              <p className="text-[10px] text-slate-400">{c.issued_by}</p>
                            </td>
                            <td className="px-4 py-3">
                              <p className={`font-medium ${isExpired?'text-rose-600':isExpiring?'text-amber-600':'text-slate-700'}`}>{c.expiry}</p>
                              {isExpired && <p className="text-[10px] text-rose-500">Hết hạn {Math.abs(diff)} ngày trước</p>}
                              {isExpiring && <p className="text-[10px] text-amber-500">Còn {diff} ngày</p>}
                            </td>
                            <td className="px-4 py-3">
                              <span className={`px-2 py-1 rounded-full text-[10px] font-bold ${isExpired?'bg-rose-100 text-rose-700':isExpiring?'bg-amber-100 text-amber-700':'bg-emerald-100 text-emerald-700'}`}>
                                {isExpired ? 'Hết hạn' : isExpiring ? 'Sắp hết hạn' : 'Còn hạn'}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <button onClick={() => {
                                const updated = workerCerts.filter(x=>x.id!==c.id);
                                setWorkerCerts(updated);
                                saveHSE('hse_worker_certs', updated);
                              }} className="text-slate-300 hover:text-rose-500 transition-colors">
                                <X size={14}/>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    {workerCerts.length === 0 && (
                      <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-400 text-xs">Chưa có chứng chỉ nào. Nhấn "Thêm chứng chỉ" để bắt đầu.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── INSPECTIONS ──────────────────────────────────────── */}
      {hseTab === 'inspections' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm font-bold text-slate-700">{inspections.length} đợt kiểm tra</p>
            <button className="flex items-center gap-1.5 px-3 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-colors">
              <Plus size={13}/> Tạo đợt kiểm tra
            </button>
          </div>
          {inspections.map(ins => (
            <div key={ins.id} className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
              <div className={`px-4 py-3 flex items-center justify-between ${ins.overall==='pass'?'bg-emerald-50 border-b border-emerald-200':ins.overall==='fail'?'bg-rose-50 border-b border-rose-200':'bg-amber-50 border-b border-amber-200'}`}>
                <div>
                  <p className="text-sm font-bold text-slate-800">{ins.area} — {ins.date}</p>
                  <p className="text-[10px] text-slate-500">Kiểm tra bởi: {ins.inspector} · Kiểm tra tiếp theo: {ins.next_date}</p>
                </div>
                <span className={`text-xs font-bold px-3 py-1 rounded-xl ${ins.overall==='pass'?'bg-emerald-100 text-emerald-700':ins.overall==='fail'?'bg-rose-100 text-rose-700':'bg-amber-100 text-amber-700'}`}>
                  {ins.overall==='pass'?'✅ Đạt':ins.overall==='fail'?'❌ Không đạt':'⚠️ Đạt có điều kiện'}
                </span>
              </div>
              <div className="divide-y divide-slate-100">
                {ins.checklist_items.map((item, i) => (
                  <div key={i} className="px-4 py-2.5 flex items-center gap-3">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg shrink-0 ${item.result==='pass'?'bg-emerald-100 text-emerald-700':item.result==='fail'?'bg-rose-100 text-rose-700':'bg-amber-100 text-amber-700'}`}>
                      {item.result==='pass'?'✓ Đạt':item.result==='fail'?'✗ Không đạt':'⚠ Có điều kiện'}
                    </span>
                    <p className="text-xs text-slate-700 flex-1">{item.item}</p>
                    {item.note && <p className="text-[10px] text-slate-400 italic">{item.note}</p>}
                  </div>
                ))}
              </div>
              {ins.follow_up && (
                <div className="px-4 py-3 bg-amber-50 border-t border-amber-200">
                  <p className="text-[10px] text-amber-800"><strong>Hành động khắc phục:</strong> {ins.follow_up}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── REPORTS / GEM ─────────────────────────────────────── */}
      {hseTab === 'reports' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-5 text-white">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center shrink-0">
                <Sparkles size={20}/>
              </div>
              <div>
                <h3 className="text-base font-bold">GEM Báo cáo HSE tự động</h3>
                <p className="text-xs text-emerald-100 mt-0.5">Tổng hợp từ dữ liệu thực tế — sự cố, vi phạm, huấn luyện, kiểm tra</p>
              </div>
            </div>
            <button onClick={generateHSEReport} disabled={gemReportLoading}
              className="flex items-center gap-2 px-4 py-2.5 bg-white text-emerald-700 rounded-xl text-sm font-bold hover:bg-emerald-50 transition-colors disabled:opacity-60">
              {gemReportLoading ? <><Loader2 size={14} className="animate-spin"/> Đang phân tích...</> : <><Sparkles size={14}/> Tạo báo cáo HSE tháng</>}
            </button>
          </div>
          {gemReport && (
            <div className="bg-white border border-emerald-200 rounded-2xl p-5">
              <p className="text-xs font-bold text-emerald-700 mb-3 flex items-center gap-1.5"><Sparkles size={12}/> Báo cáo HSE — Nàng GEM</p>
              <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">{gemReport}</div>
              <div className="flex gap-2 mt-4">
                <button onClick={() => navigator.clipboard.writeText(gemReport)}
                  className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition-colors">
                  <Copy size={12}/> Sao chép
                </button>
                <button onClick={() => setPrintHSE({ content: gemReport })}
                  className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition-colors">
                  <Printer size={12}/> In báo cáo
                </button>
              </div>
            </div>
          )}

          {/* Quick stats for report */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {[
              { label:'LTIFR', val:'0.0', desc:'Lost Time Injury Frequency Rate', color:'emerald' },
              { label:'Tổng sự cố', val:String(incidents.length), desc:'Tổng cộng từ đầu dự án', color:'rose' },
              { label:'Tổng vi phạm', val:String(violations.length), desc:`Tiền phạt: ${totalFines}K đồng`, color:'orange' },
              { label:'Hoàn thành HLuyện', val:`${trainings.filter(t=>t.status==='completed').length}/${trainings.length}`, desc:'Khóa đã hoàn thành', color:'blue' },
              { label:'Tỷ lệ tuân thủ', val:`${Math.round((violations.length===0?100:Math.max(0,100-violations.length*2)))}%`, desc:'Ước tính từ vi phạm', color:'teal' },
              { label:'Ngày an toàn', val:String(daysSafe), desc:'Ngày liên tục không TNLĐ', color:'emerald' },
            ].map(s => (
              <div key={s.label} className="bg-white border border-slate-200 rounded-2xl p-4">
                <p className="text-[10px] text-slate-400 font-semibold">{s.label}</p>
                <p className={`text-2xl font-bold mt-0.5 ${s.color==='emerald'?'text-emerald-600':s.color==='rose'?'text-rose-600':s.color==='orange'?'text-orange-600':s.color==='blue'?'text-blue-600':'text-teal-600'}`}>{s.val}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}




      {/* ── VIOLATION FORM MODAL ── */}
      <ModalForm
        open={showViolationForm}
        onClose={() => setShowViolationForm(false)}
        title="Ghi nhận vi phạm an toàn"
        subtitle="Ghi nhận vi phạm của công nhân/nhà thầu tại công trường"
        icon={<AlertTriangle size={18}/>} color="orange" width="md"
        footer={<>
          <BtnCancel onClick={() => setShowViolationForm(false)}/>
          <BtnSubmit label="Lưu vi phạm" color="orange" onClick={() => {
            if (!vioForm.description || !vioForm.worker) { notifErr('Vui lòng nhập tên công nhân và mô tả vi phạm!'); return; }
            const newV:Violation = { id:`v${Date.now()}`, date:vioForm.date||new Date().toLocaleDateString('vi-VN'),
              worker:vioForm.worker!, contractor:vioForm.contractor||'',
              description:vioForm.description!, level:vioForm.level||'nhe', photo_note:'', action:vioForm.action||'',
              fine_amount:vioForm.fine_amount||0, status:'open', recurrence:vioForm.recurrence||false };
            const updated = [newV, ...violations];
            setViolations(updated); saveHSE('hse_violations', updated);
            setShowViolationForm(false); setVioForm({ level:'nhe', status:'open', fine_amount:0 });
            notifOk('Đã ghi nhận vi phạm!');
          }}/>
        </>}
      >
        <FormGrid cols={2}>
          <FormRow label="Ngày vi phạm">
            <input value={vioForm.date||''} onChange={e=>setVioForm(f=>({...f,date:e.target.value}))}
              className={inputCls} placeholder="DD/MM/YYYY"/>
          </FormRow>
          <FormRow label="Tên công nhân *">
            <input value={vioForm.worker||''} onChange={e=>setVioForm(f=>({...f,worker:e.target.value}))}
              className={inputCls} placeholder="Họ và tên"/>
          </FormRow>
          <FormRow label="Nhà thầu">
            <input value={vioForm.contractor||''} onChange={e=>setVioForm(f=>({...f,contractor:e.target.value}))}
              className={inputCls} placeholder="Tên nhà thầu/tổ đội"/>
          </FormRow>
          <FormRow label="Mức độ vi phạm">
            <select value={vioForm.level||'nhe'} onChange={e=>setVioForm(f=>({...f,level:e.target.value as ViolationLevel}))} className={selectCls}>
              <option value="nhe">Nhắc nhở</option>
              <option value="trung">Cảnh cáo</option>
              <option value="nghiem_trong">Nghiêm trọng</option>
            </select>
          </FormRow>
        </FormGrid>
        <FormRow label="Mô tả vi phạm *">
          <textarea value={vioForm.description||''} onChange={e=>setVioForm(f=>({...f,description:e.target.value}))}
            className={inputCls} rows={3} placeholder="Mô tả chi tiết hành vi vi phạm..."/>
        </FormRow>
        <FormGrid cols={2}>
          <FormRow label="Biện pháp xử lý">
            <input value={vioForm.action||''} onChange={e=>setVioForm(f=>({...f,action:e.target.value}))}
              className={inputCls} placeholder="Hướng xử lý"/>
          </FormRow>
          <FormRow label="Tiền phạt (K đồng)">
            <input type="number" value={vioForm.fine_amount||''} onChange={e=>setVioForm(f=>({...f,fine_amount:+e.target.value}))}
              className={inputCls} placeholder="0"/>
          </FormRow>
        </FormGrid>
        <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer mt-1">
          <input type="checkbox" checked={vioForm.recurrence||false} onChange={e=>setVioForm(f=>({...f,recurrence:e.target.checked}))}/>
          Đây là vi phạm tái diễn
        </label>
      </ModalForm>
      {/* ── TRAINING FORM MODAL ── */}
      <ModalForm
        open={showTrainingForm}
        onClose={() => setShowTrainingForm(false)}
        title="Thêm khóa huấn luyện"
        subtitle="Lên kế hoạch khóa đào tạo an toàn lao động"
        icon={<BookOpen size={18}/>} color="blue" width="md"
        footer={<>
          <BtnCancel onClick={() => setShowTrainingForm(false)}/>
          <BtnSubmit label="Lưu khóa học" color="blue" onClick={() => {
            if (!traForm.title) { notifErr('Vui lòng nhập tên khóa học!'); return; }
            const newT:Training = { id:`t${Date.now()}`, title:traForm.title!, type:'Bắt buộc',
              scheduled_date:traForm.scheduled_date||'', duration_hours:traForm.duration_hours||4,
              trainer:traForm.trainer||'', participants:[], max_participants:traForm.max_participants||30,
              status:'scheduled', pass_count:0, certificate_expiry_months:12, notes:'' };
            const updated = [...trainings, newT];
            setTrainings(updated); saveHSE('hse_trainings', updated);
            setShowTrainingForm(false); setTraForm({ status:'scheduled', duration_hours:4, max_participants:30 });
            notifOk('Đã thêm khóa huấn luyện!');
          }}/>
        </>}
      >
        <FormRow label="Tên khóa học *">
          <input value={traForm.title||''} onChange={e=>setTraForm(f=>({...f,title:e.target.value}))}
            className={inputCls} placeholder="VD: An toàn lao động cơ bản"/>
        </FormRow>
        <FormGrid cols={2}>
          <FormRow label="Ngày tổ chức">
            <input value={traForm.scheduled_date||''} onChange={e=>setTraForm(f=>({...f,scheduled_date:e.target.value}))}
              className={inputCls} placeholder="DD/MM/YYYY"/>
          </FormRow>
          <FormRow label="Giảng viên">
            <input value={traForm.trainer||''} onChange={e=>setTraForm(f=>({...f,trainer:e.target.value}))}
              className={inputCls} placeholder="Họ và tên giảng viên"/>
          </FormRow>
          <FormRow label="Số giờ học">
            <input type="number" value={traForm.duration_hours||''} onChange={e=>setTraForm(f=>({...f,duration_hours:+e.target.value}))}
              className={inputCls} placeholder="4"/>
          </FormRow>
          <FormRow label="Số người tối đa">
            <input type="number" value={traForm.max_participants||''} onChange={e=>setTraForm(f=>({...f,max_participants:+e.target.value}))}
              className={inputCls} placeholder="30"/>
          </FormRow>
        </FormGrid>
      </ModalForm>
      {/* ── CERT FORM MODAL ── */}
      <ModalForm
        open={showCertForm}
        onClose={() => setShowCertForm(false)}
        title="Thêm chứng chỉ cá nhân"
        subtitle="Ghi nhận chứng chỉ an toàn của công nhân"
        icon={<Award size={18}/>} color="teal" width="md"
        footer={<>
          <BtnCancel onClick={() => setShowCertForm(false)}/>
          <BtnSubmit label="Lưu chứng chỉ" color="teal" onClick={() => {
            if (!certForm.worker_name || !certForm.cert_type) { notifErr('Vui lòng nhập tên và loại chứng chỉ!'); return; }
            const newC:WorkerCert = { id:`wc${Date.now()}`,
              worker_name:certForm.worker_name!, contractor:certForm.contractor||'',
              cert_type:certForm.cert_type!, cert_no:certForm.cert_no||'',
              issued:certForm.issued||'', expiry:certForm.expiry||'', issued_by:certForm.issued_by||'' };
            const updated = [...workerCerts, newC];
            setWorkerCerts(updated); saveHSE('hse_worker_certs', updated);
            setShowCertForm(false); setCertForm({});
            notifOk('Đã thêm chứng chỉ!');
          }}/>
        </>}
      >
        <FormGrid cols={2}>
          <FormRow label="Họ và tên *">
            <input value={certForm.worker_name||''} onChange={e=>setCertForm(f=>({...f,worker_name:e.target.value}))}
              className={inputCls} placeholder="Họ và tên công nhân"/>
          </FormRow>
          <FormRow label="Tổ đội / Nhà thầu">
            <input value={certForm.contractor||''} onChange={e=>setCertForm(f=>({...f,contractor:e.target.value}))}
              className={inputCls} placeholder="Tên tổ đội hoặc nhà thầu"/>
          </FormRow>
          <FormRow label="Loại chứng chỉ *">
            <select value={certForm.cert_type||''} onChange={e=>setCertForm(f=>({...f,cert_type:e.target.value}))} className={selectCls}>
              <option value="">Chọn loại...</option>
              <option>An toàn lao động Nhóm 1</option>
              <option>An toàn lao động Nhóm 2</option>
              <option>An toàn lao động Nhóm 3</option>
              <option>An toàn lao động Nhóm 4</option>
              <option>An toàn lao động Nhóm 5</option>
              <option>Vận hành máy xây dựng</option>
              <option>Điện công trường</option>
              <option>Làm việc trên cao</option>
              <option>PCCC cơ bản</option>
              <option>Sơ cứu y tế</option>
            </select>
          </FormRow>
          <FormRow label="Số chứng chỉ">
            <input value={certForm.cert_no||''} onChange={e=>setCertForm(f=>({...f,cert_no:e.target.value}))}
              className={inputCls} placeholder="Số hiệu chứng chỉ"/>
          </FormRow>
          <FormRow label="Ngày cấp">
            <input value={certForm.issued||''} onChange={e=>setCertForm(f=>({...f,issued:e.target.value}))}
              className={inputCls} placeholder="DD/MM/YYYY"/>
          </FormRow>
          <FormRow label="Ngày hết hạn">
            <input value={certForm.expiry||''} onChange={e=>setCertForm(f=>({...f,expiry:e.target.value}))}
              className={inputCls} placeholder="DD/MM/YYYY"/>
          </FormRow>
          <div className="col-span-2"><FormRow label="Nơi cấp">
            <input value={certForm.issued_by||''} onChange={e=>setCertForm(f=>({...f,issued_by:e.target.value}))}
              className={inputCls} placeholder="Đơn vị cấp chứng chỉ"/>
          </FormRow></div>
        </FormGrid>
      </ModalForm>

      {/* ── INCIDENT FORM MODAL (DESIGN_SYSTEM: modals at end) ── */}
      {/* Incident form */}
      <ModalForm
        open={showIncidentForm}
        onClose={() => setShowIncidentForm(false)}
        title="Báo cáo Sự cố An toàn"
        subtitle="Ghi nhận và báo cáo ngay khi phát hiện sự cố"
        icon={<AlertTriangle size={18}/>}
        color="rose" width="md"
        footer={<>
          <BtnCancel onClick={() => setShowIncidentForm(false)} />
          <BtnSubmit label="Lưu & Báo cáo" color="rose" onClick={() => {
              if (!incForm.description || !incForm.date) return;
              const newInc:Incident = { id:`i${Date.now()}`, date:incForm.date!, time:incForm.time||'', location:incForm.location||'',
            description:incForm.description!, level:incForm.level||'minor', injured:incForm.injured,
            root_cause:incForm.root_cause||'', action:incForm.action||'', status:'open', reporter:incForm.reporter||'' };
              const updated = [newInc, ...incidents];
              setIncidents(updated); saveHSE('hse_incidents', updated);
              if (incForm.level === 'major' || incForm.level === 'fatal') {
            triggerHseDoc(`Sự cố: ${incForm.description?.slice(0, 60)}`, 'HSE_INCIDENT', { incident: newInc });
              }
              setShowIncidentForm(false); setIncForm({ level:'minor', status:'open', date: new Date().toLocaleDateString('vi-VN') });
          }} />
        </>}
      >
        <FormGrid cols={2}>
          <FormRow label="Ngày xảy ra" required><input className={inputCls} placeholder="DD/MM/YYYY" value={incForm.date||''} onChange={e=>setIncForm(f=>({...f,date:e.target.value}))}/></FormRow>
          <FormRow label="Giờ"><input className={inputCls} placeholder="HH:MM" value={incForm.time||''} onChange={e=>setIncForm(f=>({...f,time:e.target.value}))}/></FormRow>
          <FormRow label="Vị trí xảy ra"><input className={inputCls} placeholder="Khu vực, tầng, vị trí cụ thể" value={incForm.location||''} onChange={e=>setIncForm(f=>({...f,location:e.target.value}))}/></FormRow>
          <FormRow label="Mức độ nghiêm trọng"><select className={selectCls} value={incForm.level} onChange={e=>setIncForm(f=>({...f,level:e.target.value as any}))}><option value="near_miss">Suýt xảy ra</option><option value="minor">Nhẹ</option><option value="medium">Trung bình</option><option value="major">Nghiêm trọng</option><option value="fatal">Tử vong</option></select></FormRow>
          <FormRow label="Người báo cáo" required><input className={inputCls} placeholder="Họ tên người báo cáo" value={incForm.reporter||''} onChange={e=>setIncForm(f=>({...f,reporter:e.target.value}))}/></FormRow>
          <FormRow label="Người bị nạn (nếu có)"><input className={inputCls} placeholder="Họ tên" value={incForm.injured||''} onChange={e=>setIncForm(f=>({...f,injured:e.target.value}))}/></FormRow>
        </FormGrid>
        <FormRow label="Mô tả chi tiết sự cố" required>
          <textarea rows={3} className={inputCls + " resize-none"} placeholder="Mô tả đầy đủ sự cố..." value={incForm.description||''} onChange={e=>setIncForm(f=>({...f,description:e.target.value}))}/>
          <VoiceCapture context="hse_incident" onResult={text => setIncForm(f=>({...f, description: text}))} className="mt-1.5"/>
        </FormRow>
        <FormRow label="Nguyên nhân gốc rễ"><input className={inputCls} placeholder="Nguyên nhân sơ bộ" value={incForm.root_cause||''} onChange={e=>setIncForm(f=>({...f,root_cause:e.target.value}))}/></FormRow>
        <FormRow label="Biện pháp xử lý / khắc phục"><input className={inputCls} placeholder="Biện pháp đã thực hiện hoặc đề xuất" value={incForm.action||''} onChange={e=>setIncForm(f=>({...f,action:e.target.value}))}/></FormRow>
        {/* S21: Image AI analysis */}
        <HSEImageAnalyzer
          projectId={_hse_pid}
          uploadedBy={ctx?.userId ?? "hse_officer"}
          compact
          onAnalysis={(result, imgUrl) => {
            setHseAnalysis(result);
            // Auto-fill form từ AI analysis
            if (!incForm.description && result.summary) setIncForm(f=>({...f, description: result.summary}));
            const photos = [{ file: new File([], "hse_ai.jpg"), dataUrl: imgUrl, geoTag: undefined }] as any;
            setIncidentPhotos(prev => [...prev, ...photos]);
          }}
        />
        {hseAnalysis && (
          <div className="text-xs bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
            GEM AI: Rủi ro <strong>{hseAnalysis.risk_level}</strong> — {hseAnalysis.violations.length} vi phạm phát hiện
          </div>
        )}
        {/* S19: Camera capture */}
        <div className="mt-2">
          <button type="button" onClick={() => setShowCamera(true)}
            className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2 hover:bg-emerald-100 transition-colors">
            <Camera size={13}/> Chụp ảnh hiện trường ({incidentPhotos.length})
          </button>
          {incidentPhotos.length > 0 && (
            <div className="flex gap-2 mt-2 flex-wrap">
              {incidentPhotos.map((p, i) => (
                <div key={i} className="relative">
                  <img src={p.dataUrl} className="w-16 h-16 object-cover rounded-lg border border-slate-200" alt={`Ảnh ${i+1}`}/>
                  {p.geoTag && <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-[8px] text-center rounded-b-lg py-0.5">GPS ✓</div>}
                </div>
              ))}
            </div>
          )}
        </div>
      </ModalForm>

      {/* S19: Camera */}
      {showCamera && (
        <CameraCapture
          projectId={_hse_pid}
          category="hse"
          uploadedBy={ctx?.userId ?? "hse_user"}
          description={`HSE Incident — ${incForm.description?.slice(0,60) ?? ""}`}
          onCapture={(result) => {
            setIncidentPhotos(prev => [...prev, result]);
            setShowCamera(false);
          }}
          onClose={() => setShowCamera(false)}
        />
      )}

      {/* ── APPROVAL QUEUE DRAWER ── */}
      {showApprovalPanel && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="flex-1 bg-black/40 backdrop-blur-sm" onClick={() => setShowApprovalPanel(false)}/>
          <div className="w-full max-w-lg bg-white shadow-2xl flex flex-col overflow-hidden">
            <ApprovalQueue
              projectId={projectId}
              projectName={selectedProject?.name || 'Dự án'}
              ctx={ctx}
              onClose={() => { setShowApprovalPanel(false); refreshHseQueue(); }}
            />
          </div>
        </div>
      )}

      {/* ── MODALS — cuối component theo DS rule 5.2 ─────────────────────── */}
      <ModalForm
        open={showPTWForm}
        onClose={() => setShowPTWForm(false)}
        title="Tạo Giấy phép Công việc (PTW)"
        subtitle="Permit to Work — yêu cầu duyệt trước khi thi công"
        icon={<ClipboardList size={18}/>}
        color="violet"
        width="lg"
        footer={<>
          <BtnCancel onClick={() => setShowPTWForm(false)}/>
          <BtnSubmit onClick={() => {
            if (!ptwForm.title?.trim())     { notifErr('Vui lòng nhập tiêu đề công việc!'); return; }
            if (!ptwForm.requester?.trim()) { notifErr('Vui lòng nhập người yêu cầu!'); return; }
            if (!ptwForm.area?.trim())      { notifErr('Vui lòng nhập khu vực thi công!'); return; }
            const checkItems = PTW_CHECKLIST[ptwForm.type ?? 'other'] ?? [];
            const unchecked  = checkItems.filter((_,i) => !ptwChecklist[`${ptwForm.type}_${i}`]);
            if (unchecked.length > 0) { notifErr(`Còn ${unchecked.length} mục checklist chưa xác nhận!`); return; }
            const newPTW: PTW = {
              id: 'ptw_' + Date.now(), type: ptwForm.type ?? 'other',
              title: ptwForm.title!, requester: ptwForm.requester!,
              contractor: ptwForm.contractor ?? '', area: ptwForm.area!,
              work_description: ptwForm.work_description ?? '',
              hazards: ptwForm.hazards ?? '', controls: ptwForm.controls ?? '',
              start_date: ptwForm.start_date ?? '', end_date: ptwForm.end_date ?? '',
              status: 'pending', created_at: new Date().toLocaleDateString('vi-VN'),
            };
            setPtws(prev => { const next = [newPTW, ...prev]; db.set('hse_ptws', _hse_pid, next); return next; });
            setShowPTWForm(false);
            setPtwForm({ type:'hot_work', status:'draft', start_date: new Date().toLocaleDateString('vi-VN'), end_date: new Date().toLocaleDateString('vi-VN'), created_at: new Date().toLocaleDateString('vi-VN') });
            setPtwChecklist({});
            notifOk('Đã tạo giấy phép — đang chờ duyệt');
          }} label="Nộp duyệt"/>
        </>}
      >
        <FormSection title="Thông tin chung">
          <FormGrid cols={2}>
            <FormRow label="Loại công việc *">
              <select className={selectCls} value={ptwForm.type} onChange={e => setPtwForm(p => ({...p, type: e.target.value as PTWType}))}>
                {(Object.entries(PTW_TYPE_LABEL) as [PTWType, string][]).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </FormRow>
            <FormRow label="Tiêu đề *"><input className={inputCls} value={ptwForm.title ?? ''} onChange={e => setPtwForm(p => ({...p, title: e.target.value}))} placeholder="Mô tả ngắn công việc"/></FormRow>
            <FormRow label="Người yêu cầu *"><input className={inputCls} value={ptwForm.requester ?? ''} onChange={e => setPtwForm(p => ({...p, requester: e.target.value}))}/></FormRow>
            <FormRow label="Nhà thầu"><input className={inputCls} value={ptwForm.contractor ?? ''} onChange={e => setPtwForm(p => ({...p, contractor: e.target.value}))}/></FormRow>
            <FormRow label="Khu vực thi công *"><input className={inputCls} value={ptwForm.area ?? ''} onChange={e => setPtwForm(p => ({...p, area: e.target.value}))}/></FormRow>
            <FormRow label="Ngày bắt đầu"><input type="date" className={inputCls} onChange={e => setPtwForm(p => ({...p, start_date: new Date(e.target.value).toLocaleDateString('vi-VN')}))}/></FormRow>
          </FormGrid>
        </FormSection>
        <FormSection title="Đánh giá rủi ro (JSA)">
          <FormGrid cols={2}>
            <FormRow label="Mô tả công việc"><textarea className={inputCls} rows={2} value={ptwForm.work_description ?? ''} onChange={e => setPtwForm(p => ({...p, work_description: e.target.value}))}/></FormRow>
            <FormRow label="Nguy cơ / Rủi ro nhận diện"><textarea className={inputCls} rows={2} value={ptwForm.hazards ?? ''} onChange={e => setPtwForm(p => ({...p, hazards: e.target.value}))}/></FormRow>
            <FormRow label="Biện pháp kiểm soát"><textarea className={inputCls} rows={2} value={ptwForm.controls ?? ''} onChange={e => setPtwForm(p => ({...p, controls: e.target.value}))}/></FormRow>
          </FormGrid>
        </FormSection>
        <FormSection title="Checklist an toàn bắt buộc">
          <div className="space-y-2">
            {(PTW_CHECKLIST[ptwForm.type ?? "other"] ?? []).map((item, i) => (
              <label key={i} className="flex items-start gap-2.5 cursor-pointer group">
                <input type="checkbox"
                  checked={!!ptwChecklist[`${ptwForm.type}_${i}`]}
                  onChange={e => setPtwChecklist(p => ({...p, [`${ptwForm.type}_${i}`]: e.target.checked}))}
                  className="mt-0.5 w-4 h-4 rounded accent-violet-600 shrink-0"/>
                <span className="text-xs text-slate-700 group-hover:text-slate-900">{item}</span>
              </label>
            ))}
          </div>
          <p className="text-[10px] text-amber-600 mt-2">⚠ Phải tick đủ tất cả trước khi nộp duyệt</p>
        </FormSection>
        <FormSection title="Hồ sơ JSA đính kèm">
          <FormFileUpload
            files={[]}
            onChange={() => {}}
            accept=".pdf,.docx,.xlsx,.jpg,.png"
            maxFiles={3}
            label="Đính kèm JSA / Biện pháp an toàn"
          />
        </FormSection>
      </ModalForm>

      <ModalForm
        open={showToolboxForm}
        onClose={() => setShowToolboxForm(false)}
        title="Ghi nhận Toolbox Talk"
        subtitle="Buổi họp an toàn đầu ca"
        icon={<MessageCircle size={18}/>}
        color="blue"
        width="md"
        footer={<>
          <BtnCancel onClick={() => setShowToolboxForm(false)}/>
          <BtnSubmit onClick={() => {
            if (!toolboxForm.topic?.trim())        { notifErr('Vui lòng nhập chủ đề!'); return; }
            if (!toolboxForm.conducted_by?.trim()) { notifErr('Vui lòng nhập người thực hiện!'); return; }
            const newTB: ToolboxTalk = {
              id: 'tb_' + Date.now(),
              date: toolboxForm.date ?? new Date().toLocaleDateString('vi-VN'),
              topic: toolboxForm.topic!, conducted_by: toolboxForm.conducted_by!,
              area: toolboxForm.area ?? '', attendees_count: toolboxForm.attendees_count ?? 0,
              key_points: toolboxForm.key_points ?? '',
              created_at: new Date().toLocaleDateString('vi-VN'),
            };
            setToolboxTalks(prev => { const next = [newTB, ...prev]; db.set('hse_toolbox', _hse_pid, next); return next; });
            setShowToolboxForm(false);
            setToolboxForm({ date: new Date().toLocaleDateString('vi-VN'), created_at: new Date().toLocaleDateString('vi-VN'), attendees_count: 0 });
            notifOk('Đã lưu Toolbox Talk!');
          }} label="Lưu"/>
        </>}
      >
        <FormGrid cols={2}>
          <FormRow label="Chủ đề *"><input className={inputCls} value={toolboxForm.topic ?? ''} onChange={e => setToolboxForm(p => ({...p, topic: e.target.value}))}/></FormRow>
          <FormRow label="Người thực hiện *"><input className={inputCls} value={toolboxForm.conducted_by ?? ''} onChange={e => setToolboxForm(p => ({...p, conducted_by: e.target.value}))}/></FormRow>
          <FormRow label="Khu vực"><input className={inputCls} value={toolboxForm.area ?? ''} onChange={e => setToolboxForm(p => ({...p, area: e.target.value}))}/></FormRow>
          <FormRow label="Số người tham dự"><input type="number" className={inputCls} value={toolboxForm.attendees_count ?? 0} onChange={e => setToolboxForm(p => ({...p, attendees_count: +e.target.value}))}/></FormRow>
          <div className="col-span-2"><FormRow label="Nội dung chính"><textarea className={inputCls} rows={3} value={toolboxForm.key_points ?? ''} onChange={e => setToolboxForm(p => ({...p, key_points: e.target.value}))}/></FormRow></div>
        </FormGrid>
      </ModalForm>

      {printHSE && <HSEReportPrint
        data={{
          reportContent: printHSE.content || '',
          projectName: selectedProject?.name || 'Dự án',
          projectId,
          preparedBy: 'Cán bộ HSE',
          stats: {
            incidents: incidents.length,
            inspections: inspections.length,
            violations: violations.length,
            trainings: trainings.length,
          }
        }}
        onClose={() => setPrintHSE(null)}
      />}
    </div>
  );
}
