GEM & CLAUDE PM Pro — Tài liệu Kinh doanh
==========================================
Cập nhật: 19/03/2026

00_Database/
  - GEM_PM_Database_KhachHang.xlsx  → Database KH + Mail Merge fields + Pipeline analytics
    · Sheet 1: Database KH (41 cột MERGE_*, dropdown validation)
    · Sheet 2: Hướng dẫn Mail Merge (từng bước + bảng mapping fields)
    · Sheet 3: Pipeline analytics (tự động đếm từ database)

01_HopDong/
  - HopDong_DichVu_SaaS_GEM_PM.docx     → Hợp đồng dịch vụ SaaS (8 điều khoản)

02_BaoGia/
  - Proposal_Enterprise_GEM_PM.docx     → Báo giá Enterprise (5 phần, điền [xxx] trước gửi)

03_Sales/
  - PhieuTiepCanKhachHang.docx          → Form qualify KH (nội bộ)
  - SalesScript_PitchOutline.docx       → Script + demo checklist + closing techniques

CÁCH DÙNG MAIL MERGE:
1. Điền thông tin KH vào GEM_PM_Database_KhachHang.xlsx (Sheet "Database KH")
2. Mở file Word (HĐ/Proposal)
3. Mailings → Select Recipients → Use Existing List → chọn file Excel
4. Insert Merge Field → chọn MERGE_* tương ứng
5. Finish & Merge → xuất file riêng từng KH
