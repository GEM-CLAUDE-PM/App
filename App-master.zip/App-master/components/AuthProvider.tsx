/**
 * AuthProvider.tsx — GEM&CLAUDE PM Pro / Nàng GEM Siêu Việt
 * React context wrapping Supabase Auth + mock dev mode.
 * Provides: useAuth() hook, <AuthGuard> component, login screen.
 *
 * Dev mode (VITE_USE_SUPABASE != 'true'):
 *   - Shows login screen with mock users
 *   - Accepts any password
 *   - Stores session in localStorage
 *
 * Prod mode (VITE_USE_SUPABASE=true):
 *   - Delegates to Supabase Auth
 *   - JWT stored by supabase-js automatically
 *   - Role read from profiles table (set via trigger on signup)
 */

import React, {
  createContext, useContext, useState, useEffect, useCallback, useRef,
} from 'react';
import {
  AuthService, Permissions, MOCK_USERS,
  JOB_LABELS, TIER_LABELS, TIER_COLORS, JOB_ROLE_TO_ROLE_ID,
  type UserProfile, type TierRole, type JobRole,
} from './supabase';
import { getRoleProjectScope } from './permissions';
import {
  LogIn, LogOut, User, Shield, ChevronDown, Loader2,
  Eye, EyeOff, AlertCircle, CheckCircle2, Lock, Building2,
  Sparkles, RefreshCw, UserCircle, Settings, X, Mail,
  Phone, Calendar, Badge, Key, Users,
} from 'lucide-react';

// ─── Context ──────────────────────────────────────────────────────────────────
interface AuthContextValue {
  user: UserProfile | null;
  perm: Permissions;
  loading: boolean;
  /** RoleId từ permissions.ts — derived từ user.job_role qua JOB_ROLE_TO_ROLE_ID */
  roleId: string;
  /** allowedProjectIds: null = L4+ (xem tất cả), string[] = L1-L3 (chỉ những project được gán) */
  allowedProjectIds: string[] | null;
  signIn: (email: string, password: string) => Promise<string | null>;
  signOut: () => Promise<void>;
  switchMockUser: (userId: string) => void;   // dev only
  isDevMode: boolean;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  perm: new Permissions(null),
  loading: true,
  roleId: 'chi_huy_truong',
  allowedProjectIds: null,
  signIn: async () => null,
  signOut: async () => {},
  switchMockUser: () => {},
  isDevMode: true,
});

export const useAuth = () => useContext(AuthContext);

// ─── Provider ─────────────────────────────────────────────────────────────────
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser]       = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const isDevMode = (import.meta as any).env?.VITE_USE_SUPABASE !== 'true';

  // Restore session on mount
  useEffect(() => {
    AuthService.restoreSession().then(u => {
      setUser(u);
      setLoading(false);
    });
  }, []);

  const signIn = useCallback(async (email: string, password: string): Promise<string | null> => {
    const { user: u, error } = await AuthService.signIn(email, password);
    if (error || !u) return error ?? 'Đăng nhập thất bại.';
    AuthService.persistSession(u);
    setUser(u);
    return null;
  }, []);

  const signOut = useCallback(async () => {
    await AuthService.signOut();
    setUser(null);
  }, []);

  const switchMockUser = useCallback((userId: string) => {
    if (!isDevMode) return;
    const u = MOCK_USERS.find(x => x.id === userId);
    if (!u) return;
    AuthService.persistSession(u);
    setUser(u);
  }, [isDevMode]);

  const perm = new Permissions(user);

  // G5 fix: derive roleId và allowedProjectIds từ Supabase user profile
  // jobRole (supabase.ts JobRole) → roleId (permissions.ts RoleId) qua JOB_ROLE_TO_ROLE_ID
  const roleId: string = user
    ? (JOB_ROLE_TO_ROLE_ID[user.job_role] || user.job_role)
    : 'chi_huy_truong';

  // allowedProjectIds:
  //   L4+ (admin tier)  → null  = thấy tất cả
  //   L3  (manager tier)→ user.project_ids (admin đã gán qua Supabase Dashboard)
  //   L1-L2 (worker tier)→ user.project_ids (cứng 1 project)
  const allowedProjectIds: string[] | null = (() => {
    if (!user) return [];
    const scope = getRoleProjectScope(roleId as any);
    if (scope === 'all') return null;         // L4+ — không giới hạn
    return user.project_ids ?? [];            // L1-L3 — chỉ project được admin gán
  })();

  // Sync vào localStorage để getCurrentScopeCtx() và buildCtxFromMember đọc được
  if (user) {
    localStorage.setItem('gem_user_role', roleId);
    if (allowedProjectIds !== null) {
      localStorage.setItem(`gem_member_projects_user_${user.id}`, JSON.stringify(allowedProjectIds));
    }
  }

  return (
    <AuthContext.Provider value={{ user, perm, loading, roleId, allowedProjectIds, signIn, signOut, switchMockUser, isDevMode }}>
      {loading ? <SplashScreen /> : !user ? <LoginScreen onSignIn={signIn} isDevMode={isDevMode} /> : children}
    </AuthContext.Provider>
  );
}

// ─── Splash Screen ────────────────────────────────────────────────────────────
function SplashScreen() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-violet-950 to-slate-900 flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-violet-600/20 rounded-2xl flex items-center justify-center mx-auto animate-pulse">
          <Sparkles size={32} className="text-violet-300" />
        </div>
        <p className="text-violet-200 font-semibold text-lg tracking-wide">Nàng GEM Siêu Việt</p>
        <div className="flex items-center gap-2 text-violet-400 text-sm">
          <Loader2 size={14} className="animate-spin" />
          Đang khởi động hệ thống...
        </div>
      </div>
    </div>
  );
}

// ─── Login Screen ─────────────────────────────────────────────────────────────
function LoginScreen({ onSignIn, isDevMode }: { onSignIn: (e: string, p: string) => Promise<string | null>; isDevMode: boolean }) {
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw]     = useState(false);
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);
  const [showQuickLogin, setShowQuickLogin] = useState(false);

  const handleLogin = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!email) { setError('Vui lòng nhập email.'); return; }
    if (!password) { setError('Vui lòng nhập mật khẩu.'); return; }
    setLoading(true); setError('');
    const err = await onSignIn(email, password);
    if (err) { setError(err); setLoading(false); }
  };

  const quickLogin = async (u: UserProfile) => {
    setLoading(true);
    await onSignIn(u.email, 'demo');
    setLoading(false);
  };

  const tierOrder: TierRole[] = ['admin', 'manager', 'worker'];
  const grouped = tierOrder.map(tier => ({
    tier,
    users: MOCK_USERS.filter(u => u.tier === tier),
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-violet-950 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">

        {/* Logo */}
        <div className="text-center space-y-3">
          <div className="w-20 h-20 bg-gradient-to-br from-violet-600 to-purple-700 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-violet-900/50">
            <Building2 size={36} className="text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-black text-white tracking-tight">GEM&CLAUDE PM Pro</h1>
            <p className="text-violet-300 text-sm mt-1 flex items-center justify-center gap-1.5">
              <Sparkles size={13} /> Nàng GEM Siêu Việt
            </p>
          </div>
          {isDevMode && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 border border-amber-500/30 rounded-full text-amber-300 text-xs font-semibold">
              <Key size={11} /> Chế độ Demo — không cần Supabase
            </div>
          )}
        </div>

        {/* Login form */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-2xl space-y-4">
          <h2 className="text-white font-bold text-lg">Đăng nhập hệ thống</h2>

          {/* Email */}
          <div>
            <label className="text-violet-200 text-xs font-semibold mb-1.5 block">Email</label>
            <div className="relative">
              <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="email" value={email}
                onChange={e => { setEmail(e.target.value); setError(''); }}
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
                placeholder="email@villaphat.vn"
                className="w-full pl-9 pr-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="text-violet-200 text-xs font-semibold mb-1.5 block">Mật khẩu</label>
            <div className="relative">
              <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type={showPw ? 'text' : 'password'} value={password}
                onChange={e => { setPassword(e.target.value); setError(''); }}
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
                placeholder={isDevMode ? 'Nhập bất kỳ (demo mode)' : '••••••••'}
                className="w-full pl-9 pr-10 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500"
              />
              <button onClick={() => setShowPw(p => !p)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200">
                {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-center gap-2 p-3 bg-rose-500/20 border border-rose-500/30 rounded-xl text-rose-300 text-sm">
              <AlertCircle size={15} className="shrink-0" /> {error}
            </div>
          )}

          {/* Submit */}
          <button
            onClick={() => handleLogin()}
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-violet-600 to-purple-600 text-white rounded-xl font-bold text-sm hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2 shadow-lg shadow-violet-900/40 transition-all"
          >
            {loading ? <><Loader2 size={15} className="animate-spin" />Đang đăng nhập...</> : <><LogIn size={15} />Đăng nhập</>}
          </button>

          {/* Quick login (dev only) */}
          {isDevMode && (
            <div>
              <button
                onClick={() => setShowQuickLogin(p => !p)}
                className="w-full flex items-center justify-center gap-2 py-2 text-violet-300 hover:text-violet-100 text-xs font-semibold transition-colors"
              >
                <Users size={13} /> Đăng nhập nhanh (Demo)
                <ChevronDown size={12} className={`transition-transform ${showQuickLogin ? 'rotate-180' : ''}`} />
              </button>

              {showQuickLogin && (
                <div className="mt-3 space-y-3 max-h-80 overflow-y-auto pr-1">
                  {grouped.map(({ tier, users }) => {
                    const tc = TIER_COLORS[tier];
                    return (
                      <div key={tier}>
                        <p className={`text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-lg mb-1.5 ${tc.bg} ${tc.text} bg-opacity-20`}>
                          {TIER_LABELS[tier]}
                        </p>
                        <div className="space-y-1.5">
                          {users.map(u => (
                            <button
                              key={u.id}
                              onClick={() => quickLogin(u)}
                              disabled={loading}
                              className="w-full flex items-center gap-3 p-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-left transition-all group disabled:opacity-50"
                            >
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${tc.bg} bg-opacity-30`}>
                                <UserCircle size={18} className={tc.text} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-white text-xs font-semibold truncate">{u.full_name}</p>
                                <p className="text-slate-400 text-[10px] truncate">{JOB_LABELS[u.job_role]}</p>
                              </div>
                              <LogIn size={13} className="text-slate-500 group-hover:text-violet-300 transition-colors shrink-0" />
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        <p className="text-center text-slate-500 text-xs">
          GEM&CLAUDE PM Pro · Powered by Nàng GEM Siêu Việt
        </p>
      </div>
    </div>
  );
}

// ─── AuthGuard — wraps pages requiring minimum tier ──────────────────────────
export function AuthGuard({ minTier = 'worker', children }: { minTier?: TierRole; children: React.ReactNode }) {
  const { perm } = useAuth();
  if (perm.atLeast(minTier)) return <>{children}</>;
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="w-16 h-16 bg-rose-100 rounded-2xl flex items-center justify-center mb-4">
        <Lock size={28} className="text-rose-500" />
      </div>
      <p className="text-slate-700 font-bold text-lg mb-2">Không có quyền truy cập</p>
      <p className="text-slate-400 text-sm">Bạn cần quyền <strong>{TIER_LABELS[minTier]}</strong> để xem nội dung này.</p>
    </div>
  );
}

// ─── UserMenu — top-right dropdown in Taskbar ─────────────────────────────────
export function UserMenu() {
  const { user, perm, signOut, switchMockUser, isDevMode } = useAuth();
  const [open, setOpen] = useState(false);
  const [showSwitch, setShowSwitch] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false); setShowSwitch(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  if (!user) return null;
  const tc = TIER_COLORS[user.tier];

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(p => !p)}
        className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-slate-100 transition-colors"
      >
        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tc.bg}`}>
          <UserCircle size={18} className={tc.text} />
        </div>
        <div className="hidden sm:block text-left">
          <p className="text-xs font-bold text-slate-700 leading-none">{user.full_name}</p>
          <p className={`text-[10px] font-semibold mt-0.5 ${tc.text}`}>{JOB_LABELS[user.job_role]}</p>
        </div>
        <ChevronDown size={13} className={`text-slate-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-50">
          {/* Profile header */}
          <div className={`p-4 ${tc.bg} bg-opacity-50`}>
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${tc.bg}`}>
                <UserCircle size={24} className={tc.text} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-slate-800 truncate">{user.full_name}</p>
                <p className={`text-xs font-semibold ${tc.text}`}>{JOB_LABELS[user.job_role]}</p>
                <span className={`inline-flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-full mt-1 ${tc.bg} ${tc.text} ${tc.border} border`}>
                  <Shield size={9} /> {TIER_LABELS[user.tier]}
                </span>
              </div>
            </div>
          </div>

          {/* Info */}
          <div className="p-3 border-b border-slate-100 space-y-2">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Mail size={12} className="text-slate-400 shrink-0" />{user.email}
            </div>
            {user.phone && (
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <Phone size={12} className="text-slate-400 shrink-0" />{user.phone}
              </div>
            )}
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Building2 size={12} className="text-slate-400 shrink-0" />
              {user.project_ids.length} dự án liên kết
            </div>
          </div>

          {/* Permissions summary */}
          <div className="p-3 border-b border-slate-100">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-2">Quyền truy cập</p>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { label: 'Hợp đồng', ok: perm.canViewContracts },
                { label: 'Tài chính', ok: perm.canViewFullFinancials },
                { label: 'QS / VO', ok: perm.canViewQS },
                { label: 'Kế toán', ok: perm.canViewAccounting },
                { label: 'HR', ok: perm.canViewHR },
                { label: 'Quản lý user', ok: perm.canManageUsers },
              ].map(p => (
                <div key={p.label} className={`flex items-center gap-1.5 text-[10px] px-2 py-1 rounded-lg font-semibold ${p.ok ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-50 text-slate-400'}`}>
                  {p.ok ? <CheckCircle2 size={10} /> : <X size={10} />}
                  {p.label}
                </div>
              ))}
            </div>
          </div>

          {/* Dev: switch user */}
          {isDevMode && (
            <div className="p-3 border-b border-slate-100">
              <button
                onClick={() => setShowSwitch(p => !p)}
                className="w-full flex items-center justify-between text-xs text-amber-600 font-semibold hover:text-amber-700"
              >
                <span className="flex items-center gap-1.5"><RefreshCw size={11} />Đổi user (Demo)</span>
                <ChevronDown size={11} className={`transition-transform ${showSwitch ? 'rotate-180' : ''}`} />
              </button>
              {showSwitch && (
                <div className="mt-2 space-y-1 max-h-48 overflow-y-auto">
                  {MOCK_USERS.map(u => (
                    <button
                      key={u.id}
                      onClick={() => { switchMockUser(u.id); setOpen(false); }}
                      className="w-full flex items-center gap-2 p-2 hover:bg-slate-50 rounded-xl text-left"
                    >
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${TIER_COLORS[u.tier].bg}`}>
                        <UserCircle size={13} className={TIER_COLORS[u.tier].text} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold text-slate-700 truncate">{u.full_name}</p>
                        <p className="text-[10px] text-slate-400 truncate">{JOB_LABELS[u.job_role]}</p>
                      </div>
                      {user.id === u.id && <CheckCircle2 size={12} className="text-emerald-500 shrink-0" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Sign out */}
          <div className="p-3">
            <button
              onClick={() => { setOpen(false); signOut(); }}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-600 rounded-xl text-sm font-semibold transition-colors"
            >
              <LogOut size={15} /> Đăng xuất
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
